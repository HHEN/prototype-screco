(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Accounts = Package['accounts-base'].Accounts;
var Soundcloud = Package['mrt:soundcloud'].Soundcloud;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mrt:accounts-soundcloud/soundcloud_server.js             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Accounts.oauth.registerService('soundcloud');                        // 1
                                                                     // 2
Accounts.addAutopublishFields({                                      // 3
  forLoggedInUser: ['services.soundcloud'],                          // 4
  forOtherUsers: ['services.soundcloud.username']                    // 5
});                                                                  // 6
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:accounts-soundcloud'] = {};

})();

//# sourceMappingURL=mrt_accounts-soundcloud.js.map
