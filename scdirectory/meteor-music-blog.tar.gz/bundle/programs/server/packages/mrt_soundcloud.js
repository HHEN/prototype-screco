(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var OAuth = Package.oauth.OAuth;
var Oauth = Package.oauth.Oauth;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;

/* Package-scope variables */
var Soundcloud;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                 //
// packages/mrt:soundcloud/soundcloud_server.js                                                    //
//                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                   //
Soundcloud = {};                                                                                   // 1
                                                                                                   // 2
//see http://developers.soundcloud.com/docs/api/reference#me                                       // 3
Soundcloud.whitelistedFields = ['id','username','permalink_url','avatar_url','country',            // 4
                      'full_name','city','description','website'];                                 // 5
                                                                                                   // 6
Oauth.registerService('soundcloud', 2, null, function(query) {                                     // 7
  var accessToken = getAccessToken(query);                                                         // 8
  var identity = getIdentity(accessToken);                                                         // 9
                                                                                                   // 10
  var serviceData = {                                                                              // 11
    accessToken: accessToken                                                                       // 12
  };                                                                                               // 13
                                                                                                   // 14
  var scFields = _.pick(identity, Soundcloud.whitelistedFields);                                   // 15
  _.extend(serviceData, scFields);                                                                 // 16
                                                                                                   // 17
  return {                                                                                         // 18
    serviceData: serviceData,                                                                      // 19
    options: {profile: {name: identity.full_name}}                                                 // 20
  };                                                                                               // 21
});                                                                                                // 22
                                                                                                   // 23
var getAccessToken = function (query) {                                                            // 24
  var config = ServiceConfiguration.configurations.findOne({service: 'soundcloud'});               // 25
  if (!config)                                                                                     // 26
    throw new ServiceConfiguration.ConfigError("Service not configured");                          // 27
                                                                                                   // 28
  var response;                                                                                    // 29
  try {                                                                                            // 30
     response = Meteor.http.post("https://api.soundcloud.com/oauth2/token", {                      // 31
      headers: {Accept: 'application/json'},                                                       // 32
      params: {                                                                                    // 33
        code: query.code,                                                                          // 34
        grant_type: "authorization_code",                                                          // 35
        client_id: config.clientId,                                                                // 36
        client_secret: config.secret,                                                              // 37
        redirect_uri: Meteor.absoluteUrl("_oauth/soundcloud?close"),                               // 38
        state: query.state                                                                         // 39
      }                                                                                            // 40
    });                                                                                            // 41
  } catch (err) {                                                                                  // 42
    throw new Error("Failed to complete OAuth handshake with Soundcloud. " + err.message);         // 43
  }                                                                                                // 44
                                                                                                   // 45
  if (response.data.error) // if the http response was a json object with an error attribute       // 46
    throw new Error("Failed to complete OAuth handshake with Soundcloud. " + response.data.error); // 47
                                                                                                   // 48
  return response.data.access_token;                                                               // 49
};                                                                                                 // 50
                                                                                                   // 51
var getIdentity = function (accessToken) {                                                         // 52
  try {                                                                                            // 53
    return Meteor.http.get("https://api.soundcloud.com/me", {                                      // 54
      params: {                                                                                    // 55
        oauth_token: accessToken,                                                                  // 56
        format: "json"                                                                             // 57
      }                                                                                            // 58
    }).data;                                                                                       // 59
  } catch (err) {                                                                                  // 60
    throw new Error("Failed to fetch identity from Soundcloud. " + err.message);                   // 61
  }                                                                                                // 62
};                                                                                                 // 63
                                                                                                   // 64
Soundcloud.retrieveCredential = function(credentialToken) {                                        // 65
  return Oauth.retrieveCredential(credentialToken);                                                // 66
};                                                                                                 // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:soundcloud'] = {
  Soundcloud: Soundcloud
};

})();

//# sourceMappingURL=mrt_soundcloud.js.map
