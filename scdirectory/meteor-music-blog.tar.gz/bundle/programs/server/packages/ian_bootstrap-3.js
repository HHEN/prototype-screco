(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ian:bootstrap-3'] = {};

})();

//# sourceMappingURL=ian_bootstrap-3.js.map
